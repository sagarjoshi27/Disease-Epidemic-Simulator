#include "Gui.h"



Gui::Gui(sf::RenderWindow* window, float startX, float startY) : window(window), startX(startX), startY(startY)
{
	if (!font.loadFromFile("arial.ttf")) {
		std::cout << "cant load text file";
	}


	background.setSize({ guiWidth - 3.f, (float)startY });
	//Grey background
	background.setFillColor(sf::Color::Color(47, 79, 79, 255));
	background.setPosition({ (float)startX, 0.f });	background.setOutlineThickness(3.f);	background.setOutlineColor(sf::Color::Color(211, 211, 211));



	button start(window, sf::Vector2f(470, 50), sf::Vector2f(150, 40), sf::Color::White, 2, sf::Color::Black, font, "Start", 24);
	buttons.push_back(start);

	button stop(window, sf::Vector2f(470, 130), sf::Vector2f(150, 40), sf::Color::White, 2, sf::Color::Black, font, "Stop", 24);
	buttons.push_back(stop);

	button pause(window, sf::Vector2f(470, 210), sf::Vector2f(150, 40), sf::Color::White, 2, sf::Color::Black, font, "Pause", 24);
	buttons.push_back(pause);

	button slow(window, sf::Vector2f(470, 470), sf::Vector2f(40, 20), sf::Color::White, 2, sf::Color::Black, font, "Slow", 10);
	buttons.push_back(slow);

	button medium(window, sf::Vector2f(530, 470), sf::Vector2f(40, 20), sf::Color::White, 2, sf::Color::Black, font, "Medium", 10);
	buttons.push_back(medium);

	button fast(window, sf::Vector2f(590, 470), sf::Vector2f(40, 20), sf::Color::White, 2, sf::Color::Black, font, "Fast", 10);
	buttons.push_back(fast);

	textInput probability(window, sf::Vector2f(590, 550), sf::Vector2f(40, 20), sf::Color::White, 2, sf::Color::Black, font, "", 10, 1000);
	inputs.push_back(probability);


	textInput recoveryRate(window, sf::Vector2f(590, 600), sf::Vector2f(40, 20), sf::Color::White, 2, sf::Color::Black, font, "", 10, 100);
	inputs.push_back(recoveryRate);

	button submit(window, sf::Vector2f(520, 630), sf::Vector2f(40, 20), sf::Color::White, 2, sf::Color::Black, font, "Update", 10);
	buttons.push_back(submit);

	statusText.setFont(font);
	statusText.setFillColor(sf::Color::Black);
	statusText.setCharacterSize(12);
	statusText.setPosition({ 460,300 });

	dayText.setFont(font);
	dayText.setFillColor(sf::Color::Black);
	dayText.setCharacterSize(12);
	dayText.setPosition({ 460,330 });

	infectedText.setFont(font);
	infectedText.setFillColor(sf::Color::Black);
	infectedText.setCharacterSize(12);
	infectedText.setPosition({ 460,360 });

	recoveredText.setFont(font);
	recoveredText.setFillColor(sf::Color::Black);
	recoveredText.setCharacterSize(12);
	recoveredText.setPosition({ 460,390 });

	speedText.setFont(font);
	speedText.setFillColor(sf::Color::Black);
	speedText.setCharacterSize(20);
	speedText.setPosition({ 510,440 });

	probabilityText.setFont(font);
	probabilityText.setFillColor(sf::Color::Black);
	probabilityText.setCharacterSize(14);
	probabilityText.setPosition({ 450,550 });

	reoveredAmountText.setFont(font);
	reoveredAmountText.setFillColor(sf::Color::Black);
	reoveredAmountText.setCharacterSize(14);
	reoveredAmountText.setPosition({ 450,600 });
}


Gui::~Gui()
{
}

void Gui::draw()
{
	window->draw(background);
	for (int i = 0; i < buttons.size(); i++) {
		buttons[i].draw();

	}

	for (int i = 0; i < inputs.size(); i++) {
		inputs[i].draw();

	}

	statusText.setString("Status: " + status);
	dayText.setString("Days active: " + std::to_string(dayCounter));
	infectedText.setString("Infected Amount: " + std::to_string(infectedCounter));
	recoveredText.setString("Recovered Amount: " + std::to_string(recoveredCounter));
	speedText.setString("Speed");
	reoveredAmountText.setString("Recovery Time");
	probabilityText.setString("Probabilty of spread");


	window->draw(statusText);
	window->draw(dayText);
	window->draw(infectedText);
	window->draw(recoveredText);
	window->draw(speedText);
	window->draw(probabilityText);
	window->draw(reoveredAmountText);
}

std::string Gui::checkClick(float mousex, float mousey)
{
	int index = -1;
	for (int i = 0; i < buttons.size(); i++) {
		if (buttons[i].isClicked(mousex, mousey)) {
			index = i;
		}
	}

	for (int i = 0; i < inputs.size(); i++) {
		if (inputs[i].isClicked(mousex, mousey)) {
			if (!(i == curSelectedIndex)) {
				inputs[curSelectedIndex].selected = false;
				curSelectedIndex = i;
				
			}
		}
	}
	if (index == -1) {
		return "";
	}
	//std::cout << buttons[index].getButtonType();
	return buttons[index].getButtonType();
}

void Gui::updateData(int d, int i, int r, std::string s)
{
	dayCounter = d;
	infectedCounter = i;
	recoveredCounter = r;
	status = s;
}

void Gui::updateText(sf::Uint32 unicode)

{
	for (int i = 0; i < inputs.size(); i++) {
		if (inputs[i].selected) {
			inputs[i].updateText(unicode);
		}
	
	}
}

sf::Vector2i Gui::getSimVars()
{
	return sf::Vector2i(inputs[0].getVal(),inputs[1].getVal());
}
