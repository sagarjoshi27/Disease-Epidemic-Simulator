#pragma once
#include "SFML\Graphics.hpp"
#include "button.h"
#include "textInput.h"
#include <vector>
#include <iostream>
#include <string>
class Gui
{
public:
	Gui(sf::RenderWindow*, float, float);
	~Gui();

	void draw();
	std::string checkClick(float mousex, float mousey);
	void updateData(int, int, int, std::string);

	void updateText(sf::Uint32);
	sf::Vector2i getSimVars();

private:
	sf::RenderWindow* window;
	float startX;
	float startY;
	std::vector<button> buttons;
	std::vector<textInput> inputs;
	sf::Font font;
	sf::Text dayText;
	sf::Text infectedText;
	sf::Text recoveredText;
	sf::Text statusText;
	sf::Text speedText;
	sf::Text reoveredAmountText;
	sf::Text probabilityText;
	int curSelectedIndex;
	

	sf::RectangleShape background;
	const float guiWidth = 200.f;

	int dayCounter = 0;
	int infectedCounter = 0;
	int recoveredCounter = 0;
	std::string status = "Waiting";
};

