#include "button.h"


button::button(sf::RenderWindow * window, sf::Vector2f pos, sf::Vector2f size, sf::Color backgroundColour, int borderWidth, sf::Color borderColour, sf::Font font, std::string buttonText, int fontSize) : window(window), pos(pos), size(size), backgroundColour(backgroundColour), borderWidth(borderWidth), borderColour(borderColour), font(font),buttonText(buttonText),fontSize(fontSize)
{
}

button::~button()
{
}

void button::draw()
{
	sf::RectangleShape button{ {size.x, size.y} };
	//Grey background
	button.setFillColor(backgroundColour);
	button.setPosition({pos.x,pos.y});
	button.setOutlineThickness(borderWidth);

	button.setOutlineColor(borderColour);

	sf::Text text;
	text.setFont(font);
	text.setString(buttonText);
	text.setFillColor(sf::Color::Black);
	text.setCharacterSize(fontSize);
	text.setPosition({ pos.x + 2, pos.y + 5 });

	window->draw(button);
	window->draw(text);
}

bool button::isClicked(float mousex, float mousey)
{
	if (mousex > pos.x && mousey > pos.y && mousex < pos.x + size.x && mousey < pos.y + size.y) {
		return true;
	}

	return false;
}

std::string button::getButtonType()
{
	return buttonText;
}


