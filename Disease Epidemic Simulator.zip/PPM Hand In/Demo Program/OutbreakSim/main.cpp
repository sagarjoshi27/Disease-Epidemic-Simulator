#include <random>
#include "newWorld.h";
#include "Gui.h";


std::vector<button> buttons;


int main()
{
	int frameRate = 60;
	int simSizeX = 445;
	int simSizeY = 720;
	sf::RenderWindow window(sf::VideoMode(simSizeX+200, simSizeY), "Outbreak Sim");
	newWorld world(&window, simSizeX, simSizeY);
	Gui gui(&window, simSizeX, simSizeY);
	window.setFramerateLimit(frameRate);
	window.setVerticalSyncEnabled(false);





	int recover, probability;
	
	//std::cout << "Enter recovery rate: ";
	//std::cin >> recover;
	//std::cout << "\n Enter Probabilty of spread:";
	//std::cin >> probability;
	
	while (window.isOpen())
	{
		sf::Event event;


		//world.updatePixel(randx, randy);
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
			{
				window.close();
			}
			else if (event.type == sf::Event::KeyPressed)
			{
				if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
				{
					window.close();
				}
				else if (sf::Keyboard::isKeyPressed(sf::Keyboard::R))
				{


				}
				else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
				{
					world.pause();
				}
			}
			else if (event.type == sf::Event::MouseButtonPressed)
			{
				if (event.mouseButton.button == sf::Mouse::Left)
				{
					std::string type = gui.checkClick(event.mouseButton.x, event.mouseButton.y);
					if (type == "") {


					}
					else if (type == "Start") {
						world.start();

					}
					else if (type == "Stop") {
						world.stop();
					}
					else if (type == "Pause") {
						world.pause();
					}
					else if (type == "Slow") {
						frameRate = 15;
						window.setFramerateLimit(frameRate);
					}
					else if (type == "Medium") {
						frameRate = 60;
						window.setFramerateLimit(frameRate);
					}
					else if (type == "Fast") {
						frameRate = 120;
						window.setFramerateLimit(frameRate);

					}
					else if (type == "Update") {
						if (world.isRunning()) {
							std::cout << "cant change while running";
						
						}
						else {
							world.setSimulationVariables(gui.getSimVars().x, gui.getSimVars().y);
						}
					
					}

				}
			}
				else if (event.type == sf::Event::TextEntered) {
					gui.updateText(event.text.unicode);
				
			
			}
		}

		
		window.clear();
		world.update();
		gui.updateData(world.dayCounter/60, world.infectedCount, world.recoveredCount, world.status);
		gui.draw();
		window.display();
	}

	return 0;
}
