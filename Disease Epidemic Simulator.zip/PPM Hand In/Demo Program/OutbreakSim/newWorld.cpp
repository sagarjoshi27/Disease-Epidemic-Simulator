#include "newWorld.h"
#include <ctime>



newWorld::newWorld(sf::RenderWindow *window, int simSizeX, int simSizeY) : window(window), simSizeX(simSizeX), simSizeY(simSizeY)
{
	srand(time(NULL));
	worldSetup();


}


newWorld::~newWorld()
{
}

void newWorld::worldSetup() {

	//Loads of the wantyed image as the background image
	if (!imageBuffer.loadFromFile(file))
	{
		std::cout << "ERROR CANNOT FIND FILE";
	}

	//Creates a vector of type person which will be used to store all the data about the pixel
	people.resize(simSizeX*simSizeY);


	for (int x = 0; x < simSizeX; x++) {
		for (int y = 0; y < simSizeY; y++) {
			auto index = getIndex(x, y);
			auto type = people[index].getType();

			people[index].pos.x = x;
			people[index].pos.y = y;


			if (imageBuffer.getPixel(x,y) == waterColour) {
				people[index].setType(PersonType::Ignore);
			}

		}
	}

	chooseStartPoint();
}

void newWorld::updatePixel(int x, int y) {
	imageBuffer.setPixel(x, y, sf::Color(sf::Color::Red));
}

void newWorld::SetPixelColour(int x, int y, sf::Color color) {
	imageBuffer.setPixel(x, y, color);
}

void newWorld::updateImage() {
	textureBuffer.loadFromImage(imageBuffer);
	bufferSprite.setTexture(textureBuffer);
}

void newWorld::draw() {
	window->draw(bufferSprite);
}

void newWorld::update() {
	if (!paused && running) {
		spread();
	}
	updateImage();
	draw();
}

void newWorld::pause()
{
	if (paused) {
		paused = !paused;
		status = "Running";
		
		
	}
	else {
		paused = !paused;
		status = "Paused";
	
	}
	
}

void newWorld::start() {
	running = true;
	status = "Running";
}



void newWorld::stop()
{
	infectedList.clear();
	changeToInfected.clear();
	for (int x = 0; x < simSizeX; x++) {
		for (int y = 0; y < simSizeY; y++) {
			people[getIndex(x, y)].restartInfectedTime();

			if (people[getIndex(x, y)].getType() == PersonType::Infectious || people[getIndex(x, y)].getType() == PersonType::Recovered) {
				people[getIndex(x, y)].setType(PersonType::Susceptible);
			}
		}
	}
	dayCounter = 0;
	recoveredCount = 0;
	infectedCount = 0;
	worldSetup();
	running = false;
	paused = false;
	status = "Waiting";
}

void newWorld::setSimulationVariables(int probOfSpread, int recoverRate)
{
	probabilityOfSpread = probOfSpread;
	recoveryTime = recoverRate;

	std::cout << probabilityOfSpread;
	std::cout << recoveryTime;
}

bool newWorld::isRunning()
{
	return running;
}

bool newWorld::isValidSpread(int x, int y) {
	if (x < 0 || x >= simSizeX || y < 0 || y >= simSizeY) {
		return false;
	}

	auto index = getIndex(x, y);
	if (people[index].getType() == PersonType::Susceptible) {
		return true;
	}

	return false;
}

void newWorld::spread() {

	dayCounter++;

	for (int i = 0; i < infectedList.size(); i++) {
		people[infectedList[i]].incremenetInfectedTime();
	
	}

	for (int i = 0; i < changeToInfected.size(); i++) {
		infectedList.push_back(changeToInfected[i]);
		people[changeToInfected[i]].setType(PersonType::Infectious);
		SetPixelColour(people[changeToInfected[i]].pos.x, people[changeToInfected[i]].pos.y, people[changeToInfected[i]].getColourFromType());
		
	}


	for (int i = 0; i < infectedList.size(); i++) {
		//Recovery time
		if (people[infectedList[i]].getInfectedTime() > recoveryTime) {
			people[infectedList[i]].setType(PersonType::Recovered);
			sf::Vector2i pos = posFromIndex(infectedList[i]);
			SetPixelColour(people[infectedList[i]].pos.x, people[infectedList[i]].pos.y, people[infectedList[i]].getColourFromType());
			auto origSize = infectedList.size();
			infectedList.erase(infectedList.begin() + i);
			recoveredCount++;
		}
	}

	infectedCount = infectedList.size();

	if (infectedList.empty()) {
		running = false;
		status = "Finished";
	}

	changeToInfected.clear();


	for (int i = 0; i < infectedList.size(); i++) {
		for (int x = -1; x < 2; x++) {
			for (int y = -1; y < 2; y++) {
				if ((x == -1 && y == -1) || (x == 1 && y == -1) || (x == -1 && y == 1) || (x == 1 && y == 1) || (x == 0 && y == 0)) {
				
				
				}else{
				sf::Vector2i infectedPos = posFromIndex(infectedList[i]);
				int indexOfNeighbour = getIndex(people[infectedList[i]].pos.x + x, people[infectedList[i]].pos.y + y);
				
				if (people[indexOfNeighbour].getType() == PersonType::Susceptible) {

					if ((rand() % 1000) < probabilityOfSpread) {

						changeToInfected.push_back(indexOfNeighbour);

					}
				}
				
				}
			
			}
		
		}
	}


}

int newWorld::getIndex(int x, int y)
{
	return  x + simSizeX * y;
}

sf::Vector2i newWorld::posFromIndex(int index) {
	return sf::Vector2i(index / simSizeX, index%simSizeY);
}

void newWorld::chooseStartPoint()
{
	int randX = rand() % simSizeX;
	int randY = rand() % simSizeY;


	if (isValidSpread(randX, randY)) {
		
		auto index = getIndex(randX, randY);
		people[index].setType(PersonType::Infectious);
		SetPixelColour(randX, randY, people[index].getColourFromType());
		infectedList.push_back(index);
	}
	else {
		chooseStartPoint();
	}
}

