#pragma once
#include <string>
#include <SFML/Graphics.hpp>
#include <iostream>
#include <algorithm>
#include "person.h";
class newWorld
{
public:
	newWorld(sf::RenderWindow *window, int simSizeX, int simSizeY);
	~newWorld();
	void worldSetup();
	void updatePixel(int, int);

	void SetPixelColour(int x, int y, sf::Color color);

	void updateImage();

	bool isValidSpread(int, int);

	void spread();

	int getIndex(int x, int y);

	sf::Vector2i posFromIndex(int index);

	void chooseStartPoint();

	void draw();

	void update();

	void pause();


	void stop();

	void start();

	sf::Sprite bufferSprite;
	sf::Image imageBuffer;
	sf::Texture textureBuffer;

	void setSimulationVariables(int,int);

	int dayCounter = 0;
	int infectedCount = 0;
	int recoveredCount = 0;
	std::string status;

	std::vector<person> people;

	bool isRunning();
private:
	std::string file = "UK.png";
	sf::RenderWindow *window;

	sf::Color waterColour = sf::Color::Color(0, 19, 127, 255);
	sf::Color landColour = sf::Color::Color(137, 175, 111);

	int simSizeX;
	int simSizeY;

	std::vector<int> infectedList;
	std::vector<int> changeToInfected;

	int longestTime;
	int longestTimePos;

	int indexOfLongestTime = 0;
	
	bool paused = false;
	//good values [50,10]
	int recoveryTime = 10;
	//Out of a thousand
	int probabilityOfSpread = 50;

	bool running;

	


};

