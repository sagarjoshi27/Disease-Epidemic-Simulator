#include "person.h"




person::person()
{
	type = PersonType::Susceptible;
}




person::~person()
{
}

PersonType person::getType() {
	return type;
}

void person::setType(PersonType newType) {
	type = newType;
}

sf::Color person::getColourFromType() {
	if (type == PersonType::Infectious) {
		return sf::Color::Red;
	}
	else if (type == PersonType::Recovered) {
		return sf::Color::Green;
	}
	else if (type == PersonType::Susceptible) {
		return sf::Color::Color(255, 255, 255);
	}
	else {
		return sf::Color::Magenta;
	}

}
PersonType person::generateType() {
	int randNo = rand() % 100;
	//std::cout << randNo;
	if (randNo < 1) {
		return PersonType::Infectious;
	}
	else {
		return PersonType::Recovered;
	}


}

std::string person::typeToString() {
	if (type == PersonType::Infectious) {
		return "Infectious";
	}
	else if (type == PersonType::Recovered) {
		return "Recovered";
	}
	else if (type == PersonType::Susceptible) {
		return "Susceptible";
	}
	else {
		return "Ignore";
	}

}

int person::getInfectedTime() {
	return infectiousTime;
}

void person::restartInfectedTime()
{
	infectiousTime = 0;
}

void person::incremenetInfectedTime() {
	infectiousTime++;

}

bool person::isSusceptible() {
	return type == PersonType::Susceptible;
}
