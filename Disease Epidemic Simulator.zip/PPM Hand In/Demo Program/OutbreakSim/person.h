#pragma once
#include <random>
#include <ctime>
#include <iostream>
#include <SFML/Graphics.hpp>
enum class PersonType
{
	Infectious = 0,
	Susceptible = 1,
	Recovered = 2,
	Ignore = 3

};

class person
{
public:
	person();
	~person();
	
	PersonType getType();

	void setType(PersonType newType);

	sf::Color getColourFromType();

	PersonType generateType();

	std::string typeToString();

	int getInfectedTime();

	void restartInfectedTime();

	void incremenetInfectedTime();

	bool isSusceptible();

	sf::Vector2i pos;



private:
	bool isInfected = false;

	PersonType type;

	int infectiousTime = 0;
};

