#include "textInput.h"



textInput::textInput(sf::RenderWindow * window, sf::Vector2f pos, sf::Vector2f size, sf::Color backgroundColour, int borderWidth, sf::Color borderColour, sf::Font font, std::string buttonText, int fontSize, int maxValue) : window(window), pos(pos), size(size), backgroundColour(backgroundColour), borderWidth(borderWidth), borderColour(borderColour), font(font), buttonText(buttonText), fontSize(fontSize), maxValue(maxValue)
{
}

textInput::~textInput()
{
}

void textInput::draw()
{
	sf::RectangleShape button{ { size.x, size.y } };
	//Grey background
	sf::Color temp;
	if (selected) {
		temp = sf::Color::Red;
	}
	else {
		temp = backgroundColour;
	}

	button.setFillColor(temp);
	button.setPosition({ pos.x,pos.y });
	button.setOutlineThickness(borderWidth);

	button.setOutlineColor(borderColour);

	sf::Text text;
	text.setFont(font);
	text.setString(curText);

	text.setFillColor(sf::Color::Black);
	text.setCharacterSize(fontSize);
	text.setPosition({ pos.x + 2, pos.y + 5 });

	window->draw(button);
	window->draw(text);
}

bool textInput::isClicked(float mousex, float mousey)
{
	if (mousex > pos.x && mousey > pos.y && mousex < pos.x + size.x && mousey < pos.y + size.y) {
		selected = !selected;
		return true;
	}

	return false;

}

void textInput::updateText(sf::Uint32 u)
{

	char letter = static_cast<char>(u);
	if (u == 8) {
		if (curText.length() != 0) {
			curText.erase(curText.end() - 1);
		}
	
	}
	else {
		if (isdigit(letter)) {
			curText += letter;

			if(stoi(curText) > maxValue){
				curText = std::to_string(maxValue);
			}
		}
	}
}

int textInput::getVal()
{
	return stoi(curText);
}




