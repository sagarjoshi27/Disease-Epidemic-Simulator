#pragma once
#include "button.h";

class textInput
{
public:
	textInput(sf::RenderWindow*, sf::Vector2f, sf::Vector2f, sf::Color, int, sf::Color, sf::Font, std::string, int, int);
	~textInput();

	void draw();

	bool selected = false;

	bool isClicked(float mousex, float mousey);

	void updateText(sf::Uint32);

	int getVal();

private:
	sf::Vector2f pos, size;
	sf::RenderWindow* window;
	sf::Color backgroundColour, borderColour;
	int borderWidth, fontSize;
	sf::Font font;
	std::string buttonText;
	int maxValue;
	

	std::string curText = "";

};

